
//An instance of MainView is made whenever the app is run.

var tableView;
var motorList;


//The rendered main view is put on the page.
$(document).ready(function(){
	console.log("here");
	motorList = new MotorList();
	
//	$(document).on("click", "#myModalLink", function(){
//	  $('#modal').modal('show');});
	
	motorList.fetch({
		success: function(data){
			//alert(JSON.stringify(data));
			console.log("data fetched");
			tableView = new TableView({collection: motorList});
			console.log(tableView.$el);
		}
	});
});

