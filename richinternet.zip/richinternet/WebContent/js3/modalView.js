//ModalView builds a list item for each wine.
var ModalView = Backbone.View.extend({
  model: Motor,
 // tagName:'li',
  events:{
	  "click #delete":"deleteMotor",
	  "click #newmotor":"newMotor",
	  "click #save": "saveMotor"
	  
	  
  },
  alertStatus: function(e){
	  alert('Button on modal clicked');
	},
    render:function(){
		 var template= _.template($('#modal_details').html(), this.model.toJSON());
		return this.$el.html(template);
		
  },
  render2:function(){
		 var template= _.template($('#modal_editMotor').html(), this.model.toJSON());
		return this.$el.html(template);
		
},
	saveMotor: function(){
		if($("#motorID").val()==""){
			var motor = new Motor();
		}else{
			var motor = new Motor({id:$("#motorId").val()});
		}
		motor.fetch({
		});
		motor.save({
			id:null,
			make:$("#make").val(),
			year:$("#year").val(),
			mileage:$("#mileage").val(),
			colour:$("#colour").val(),
			engine:$("#engine").val(),
			picture:$("#pictureedit").val(),
			description:$("#descriptionedit").val()},{
		
				success: function(){
					alert("update chenggong");
				}
		});
	},
	newMotor: function(){
		$("#motorId").val("");
		$("#make").val("");
		$("#year").val("");
		$("#mileage").val("");
		$("#colour").val("");
		$("#engine").val("");
		$("#pictureedit").val("");
		$("#descriptionedit").val("");
	},
	
	deleteMotor: function(){
		alert("进入delete");
		var motor5 = new Motor({id:$("#motorId").val()});
		motor5.destory();
	}
});
