var rootURL = "http://localhost:8080/Motorbikes/rest/motors";
var Motor = Backbone.Model.extend({
	urlRoot:rootURL,
	defaults:{ 
	    "id": null,
	    "make": "Blahhh",
	    "year": "Blahhh",
	    "mileage": "Blahhh",
	    "colour": "Blahhh",
	    "engine": "Blahhh",
	    "description": "Blahhh",
	    "picture": "Blahhh"},
  initialize: function(){
    console.log("book init");
    this.on('change', function(){
    	console.log('Values for a model have changed');
    });
  }
});



var MotorList = Backbone.Collection.extend({
	model: Motor,
	url:rootURL});
 


