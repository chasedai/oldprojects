//BookView builds a list item for each book.
var MotorView = Backbone.View.extend({
  model: Motor,
  tagName:'tr',
  events:{
	  "click .more": "alertStatus",
	  "click .editMotor":"showEditDialog"
  },
  alertStatus: function(e){
	  alert('Hello');
	  var motor1=this.model;
	  $('#modal').html(new ModalView({model:motor1}).render());
	  $('#modal').modal('show');
  },
  showEditDialog: function(e){
	  alert('Helloedit');
	  var motor2=this.model;
	  $('#modal').html(new ModalView({model:motor2}).render2());
	  $('#modal').modal('show');
  },
    render:function(){
		 var template= _.template($('#booklist').html(), this.model.toJSON());
		return this.$el.html(template);
		
  }
});
