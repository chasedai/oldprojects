package utils;

import java.util.Arrays;

public class decryptionTools {

	//Arrays to be decrypted
		private String[] bin00 = {
				"3","f"
		};
		@SuppressWarnings("unused")
		private String[] bin01= {
			"0","1","4","5","8"	
		};
		private String[] bin10= {
				"2","6","9"
		};
		private String[] bin11= {
			"7","d"	
		};
	
	//Reverse
	public String deReverse(String encrypted) {
		int i = encrypted.length();
		return encrypted.substring(i/2,i) + encrypted.substring(0, i/2);
	}
	
	//Decode -> original binary
	public String decodeToBin(String encrypted) {
		String temp = "";
		for(int i=0; i<encrypted.length();i++) {
			String singchar = encrypted.substring(i, i+1);
			if(ifIncluded(bin00,singchar)) {
				temp+="00";
			}else if(ifIncluded(bin11,singchar)) {
				temp+="11";
			}else if(ifIncluded(bin10,singchar)) {
				temp+="10";
			}else {
				temp+="01";
			}
		}
		return temp;
	}
	
	//decode single char - 8 digits binary
	public String decodeBin(String bin) {
		String temp="";
		for(int i=0;i<bin.length();i+=8) {
			int charCode = Integer.parseInt(bin.substring(i, i+8), 2);
			temp+=new Character((char)charCode).toString();
		}
		
		return temp;
	}
	
	//If target is included in the array
	public static boolean ifIncluded(String[] arr, String targetValue) {
	    return Arrays.asList(arr).contains(targetValue);
	}
	
}
