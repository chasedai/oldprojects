package utils;


/**
 * All support algorithms
 * @author Chase
 *
 */
public class encryptionTools {

	//Arrays to be encrypted
	private String[] bin00 = {
			"3","f"
	};
	private String[] bin01= {
		"0","1","4","5","8"	
	};
	private String[] bin10= {
			"2","6","9"
	};
	private String[] bin11= {
		"7","d"	
	};
	
	
	//String to binary, no space. only suitable for single byte language
	public String StrToBinstr(String str) {
		char[] strChar=str.toCharArray();
        String result="";
        for(int i=0;i<strChar.length;i++){
        	String temp = Integer.toBinaryString(strChar[i]);
        	if(temp.length()<8) {
        		for(int k=0;k< 8-temp.length();k++) {
        			result += "0";
        		}
        		result += temp;
        	}else {
        		result += temp;
        	}
        }
        return result;
    }
	
	//Encrypt original binary
	public String encryptOriginalBin(String oriBin) {
		String temp = "";
		for(int i=0; i < oriBin.length(); i+=2) {
			String digits = oriBin.substring(i, i+2);
			if(digits.equals("00")) {
				temp += bin00[generateNo(2)];
			}else if(digits.equals("01")) {
				temp += bin01[generateNo(5)];
			}else if(digits.equals("10")) {
				temp += bin10[generateNo(3)];
			}else {
				temp += bin11[generateNo(2)];
			}
		}
//		System.out.println(temp);
		return temp;
	}
	
	//Reverse String
	public String reverseStr(String original) {
		int i = original.length();
		return original.substring(i/2,i) + original.substring(0, i/2);
	}
	
	//Generate random number
	public int generateNo(int i) {
		return (int)(Math.random()*i);
	}
	
}
