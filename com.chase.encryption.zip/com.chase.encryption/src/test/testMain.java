package test;


import utils.decryptionTools;
import utils.encryptionTools;

public class testMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		encryptionTools tool = new encryptionTools();
		String encrypted = tool.reverseStr(tool.encryptOriginalBin(tool.StrToBinstr("http://www.chasedai.com")));
		System.out.println("加密后："+encrypted);
		System.out.println("---------------");
		decryptionTools dT = new decryptionTools();
		String decrypted = dT.decodeBin(dT.decodeToBin(dT.deReverse("fd596f42f117370685121f42315690f9d6493706dd86d812630d1f070f4733f792f6d732dd17170d171787f6d246")));
		System.out.println("解密后："+ decrypted);
	}

}
